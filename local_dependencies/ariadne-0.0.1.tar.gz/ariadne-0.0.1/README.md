# Ariadne
